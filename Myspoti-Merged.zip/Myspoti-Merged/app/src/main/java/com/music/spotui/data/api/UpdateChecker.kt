package com.music.spotui.data.api

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import android.content.Context
import app.myspoti.engine.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * New version check against the GitHub releases of [BuildConfig.UPDATE_REPO]
 * (set by the CI build; empty in local builds, which never check).
 * Automatic checks at most once an hour (launch/resume) and every 6 h while open. The release's
 * APK is downloaded and installed in the app ([AppUpdater]).
 */
object UpdateChecker {
    /** [apkUrl]: the release's signed APK; blank when the release has none (then its page opens). */
    data class Release(val version: String, val pageUrl: String, val notes: String = "", val apkUrl: String = "")

    /** Launch / resume check: not more often than this (releases can come several a day). */
    const val INTERVAL_MS = 3_600_000L
    /** While the app stays open, the check runs again this often. */
    const val PERIODIC_MS = 6 * 3_600_000L
    /** After a failed automatic check (offline, rate limit), wait this long before trying again. */
    private const val RETRY_MS = 10 * 60_000L
    private val http by lazy { OkHttpClient.Builder().callTimeout(10, TimeUnit.SECONDS).addInterceptor(com.music.spotui.data.DataSaver.interceptor).build() }

    /** Answer of [refresh]: the check always asks GitHub, whatever was cached. */
    sealed interface Outcome {
        data class Found(val release: Release) : Outcome
        data object UpToDate : Outcome
        /** [rateLimited]: GitHub refused for too many requests (about an hour on a shared network). */
        data class Failed(val rateLimited: Boolean) : Outcome
    }

    private sealed interface Fetch {
        data class Ok(val release: Release?) : Fetch
        data class Err(val rateLimited: Boolean) : Fetch
    }

    /** When the last successful check ran (epoch ms), 0 if never. */
    fun lastChecked(context: Context): Long =
        context.getSharedPreferences("updates", Context.MODE_PRIVATE).getLong("checked_at", 0L)

    /**
     * Automatic check (launch, resume, periodic). [manual]: a release dismissed with "Later" is
     * offered again (the automatic check stays quiet about it). Skipped when the last
     * successful check is less than [INTERVAL_MS] old; a failed one is retried after [RETRY_MS]
     * and never erases the release already known.
     */
    suspend fun check(context: Context, manual: Boolean = false): Release? = withContext(Dispatchers.IO) {
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isBlank()) return@withContext null
        val prefs = context.getSharedPreferences("updates", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now - prefs.getLong("checked_at", 0L) < INTERVAL_MS || now - prefs.getLong("tried_at", 0L) < RETRY_MS) return@withContext pending(prefs, manual)
        store(prefs, fetch(repo, force = false), now)
        pending(prefs, manual)
    }

    /**
     * "Check now" from Settings: bypasses the throttle, the stored answer and every HTTP/CDN
     * cache, and says what happened.
     */
    suspend fun refresh(context: Context): Outcome = withContext(Dispatchers.IO) {
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isBlank()) return@withContext Outcome.UpToDate
        val prefs = context.getSharedPreferences("updates", Context.MODE_PRIVATE)
        val result = fetch(repo, force = true)
        store(prefs, result, System.currentTimeMillis())
        when (result) {
            is Fetch.Err -> Outcome.Failed(result.rateLimited)
            is Fetch.Ok -> pending(prefs, manual = true)?.let { Outcome.Found(it) } ?: Outcome.UpToDate
        }
    }

    private fun store(prefs: android.content.SharedPreferences, result: Fetch, now: Long) {
        val e = prefs.edit()
        when (result) {
            // A failure keeps the last answer: "up to date" must not come from a failed request.
            is Fetch.Err -> e.putLong("tried_at", now)
            is Fetch.Ok -> e.putLong("checked_at", now).putLong("tried_at", 0L)
                .putString("version", result.release?.version).putString("url", result.release?.pageUrl)
                .putString("notes", result.release?.notes).putString("apk", result.release?.apkUrl)
        }
        e.apply()
    }

    private fun fetch(repo: String, force: Boolean): Fetch = try {
        // Stable builds follow "latest", which never includes pre-releases. A beta build
        // reads the list: the newest beta, compared with [isNewer].
        // Both channels read the list: the repository also carries Myspoti's releases (2.x, whose
        // "latest" is one of them), never this app's.
        val bust = if (force) "&_=${System.currentTimeMillis()}" else ""
        val url = "https://api.github.com/repos/$repo/releases?per_page=20$bust"
        val request = Request.Builder().url(url).header("Accept", "application/vnd.github+json")
            .apply { if (force) { header("Cache-Control", "no-cache, no-store, max-age=0"); header("Pragma", "no-cache") } }.build()
        http.newCall(request).execute().use { r ->
            if (!r.isSuccessful) return@use Fetch.Err(r.code == 429 || (r.code == 403 && r.header("x-ratelimit-remaining") == "0"))
            val text = r.body.string()
            val list = org.json.JSONArray(text).let { a -> (0 until a.length()).map { a.getJSONObject(it) } }
            // One app for both channels: the stable channel takes releases only, the beta channel
            // the newest of releases and pre-releases (see [setBetaChannel]).
            // A pre-release that is not a version of the app (a test build's tag) is never offered.
            Fetch.Ok(newest(list))
        }
    } catch (e: Exception) { Fetch.Err(false) }

    /**
     * The newest release of this app and channel in [releases] (GitHub's list): a stable build takes
     * releases, a beta pre-releases, and only those that carry this app's APK for this phone. The
     * repository also holds Myspoti's releases (2.x, numbered above this app's 1.x, with Myspoti APKs
     * this app cannot install): read as this app's, they were offered as updates opening their page.
     */
    internal fun newest(releases: List<JSONObject>, beta: Boolean = isBeta, abis: List<String> = deviceAbis, name: String = BuildConfig.APK_NAME): Release? =
        releases.filter { !it.optBoolean("draft") && (beta || !it.optBoolean("prerelease")) && isVersionTag(it.optString("tag_name")) }
            // Each release's APKs are named after its own kind (a pre-release's "Myspoti-Beta-...").
            .map { Release(it.getString("tag_name").removePrefix("v"), it.getString("html_url"), cleanNotes(it.optString("body")), apkAsset(it, it.optBoolean("prerelease"), abis, name)) }
            .filter { it.apkUrl.isNotEmpty() }
            .reduceOrNull { best, next -> if (isNewer(next.version, best.version)) next else best }

    /** The newer release last seen, dismissed or not (no request): what Settings > About shows. */
    fun known(context: Context): Release? =
        pending(context.getSharedPreferences("updates", Context.MODE_PRIVATE), true)

    /** The latest release known, if newer than this build and (unless [manual]) not dismissed. */
    private fun pending(prefs: android.content.SharedPreferences, manual: Boolean = false): Release? {
        val version = prefs.getString("version", null) ?: return null
        val url = prefs.getString("url", null) ?: return null
        if (!manual && prefs.getString("dismissed", null) == version) return null
        return Release(version, url, prefs.getString("notes", null).orEmpty(), prefs.getString("apk", null).orEmpty()).takeIf { isNewer(version, BuildConfig.VERSION_NAME) }
    }

    /** The ABIs a release carries one APK for, and their names in it (as app/build.gradle.kts `collectApks`). */
    internal val RELEASE_ABIS = mapOf("arm64-v8a" to "ARMv8", "armeabi-v7a" to "ARMv7")

    /** "v2.4.0", "2.5.0-beta.1": a version of the app, not some other tag ("automix2-build205"). */
    internal fun isVersionTag(tag: String): Boolean = Regex("v?\\d+(\\.\\d+)+(-[0-9A-Za-z.]+)?").matches(tag)

    /**
     * The release's APK download link for this app's channel and this phone. A release carries
     * `<name>-<version>-ARMv8.apk`, `-ARMv7.apk`, `-universal.apk` and `-TV.apk` (betas:
     * `<name>-Beta-<version>-...`), [name] following the app id (see APK_NAME in
     * app/build.gradle.kts), and the first of [abis] (the phone's, most preferred first) that has
     * one wins, so a 64-bit phone that also runs armeabi-v7a takes ARMv8. Only this app's and this
     * channel's APK: another one (the other channel, or Myspoti's own `Myspoti-...` builds) is a
     * different package that Android cannot install over this one, so a name that matches none
     * (or no APK for this phone's ABIs) gives no link, and the release page opens instead.
     */
    internal fun apkAsset(release: JSONObject, beta: Boolean = isBeta, abis: List<String> = deviceAbis, name: String = BuildConfig.APK_NAME): String {
        val assets = release.optJSONArray("assets") ?: return ""
        val version = release.optString("tag_name").removePrefix("v")
        val named = "${if (beta) "$name-Beta" else name}-$version"
        val byName = (0 until assets.length()).map { assets.getJSONObject(it) }.associateBy { it.optString("name") }
        return abis.filter { it in RELEASE_ABIS }.map { "$named-${RELEASE_ABIS.getValue(it)}.apk" }
            .firstNotNullOfOrNull { byName[it] }?.optString("browser_download_url").orEmpty()
    }

    /** This phone's ABIs, most preferred first. */
    private val deviceAbis: List<String> get() = android.os.Build.SUPPORTED_ABIS.toList()

    fun dismiss(context: Context, release: Release) {
        context.getSharedPreferences("updates", Context.MODE_PRIVATE).edit()
            .putString("dismissed", release.version).apply()
    }

    /**
     * The release description as plain lines for the update window: the CHANGELOG section,
     * without GitHub's generated part, Markdown emphasis or link syntax.
     */
    fun cleanNotes(body: String): String = body
        .substringBefore("**Full Changelog**").substringBefore("## What's Changed")
        .lines().map { it.trimEnd() }
        .filter { it.isNotBlank() }
        .joinToString("\n") { line ->
            line.replace("**", "").replace(Regex("\\[([^]]+)]\\([^)]+\\)"), "$1")
                .replace(Regex("^(\\s*)[-*] "), "$1• ")
        }
        .trim()

    /** This build itself is a beta ("2.0.0-beta.1") or a dev build: the beta channel is its default. */
    val isBetaBuild get() = BuildConfig.VERSION_NAME.contains("-beta") || BuildConfig.DEBUG

    /**
     * The update channel chosen in About: beta also receives pre-releases, and shows the beta tools
     * (the log button). Observable, so a change shows at once.
     */
    var isBeta by androidx.compose.runtime.mutableStateOf(isBetaBuild)
        private set

    private const val KEY_CHANNEL = "channel"

    /** Reads the chosen channel; called once at startup. */
    fun init(context: Context) {
        val saved = context.getSharedPreferences("updates", Context.MODE_PRIVATE).getString(KEY_CHANNEL, null)
        isBeta = when (saved) { "beta" -> true; "stable" -> false; else -> isBetaBuild }
    }

    /** Switches channel; the next check asks GitHub again instead of reusing the other channel's answer. */
    fun setBetaChannel(context: Context, beta: Boolean) {
        if (beta == isBeta) return
        isBeta = beta
        context.getSharedPreferences("updates", Context.MODE_PRIVATE).edit()
            .putString(KEY_CHANNEL, if (beta) "beta" else "stable")
            .putLong("checked_at", 0L).putLong("tried_at", 0L)
            .remove("version").remove("url").remove("notes").remove("apk").remove("dismissed")
            .apply()
    }

    /**
     * "1.10.0" > "1.9.2". A release is newer than its betas ("2.0.0" > "2.0.0-beta.3"), and
     * betas compare by number ("2.0.0-beta.2" > "2.0.0-beta.1").
     */
    fun isNewer(candidate: String, current: String): Boolean {
        fun parts(v: String) = v.substringBefore('-').split('.').map { it.toIntOrNull() ?: 0 }
        val a = parts(candidate); val b = parts(current)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }; val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        // Same version number: release > beta, then the higher beta.
        fun beta(v: String) = if (!v.contains('-')) Int.MAX_VALUE else Regex("(\\d+)$").find(v)?.value?.toIntOrNull() ?: 0
        return beta(candidate) > beta(current)
    }
}
