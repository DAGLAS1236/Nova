package app.myspoti.host.android

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebViewClient
import app.myspoti.spotify.bridge.AdBlock
import app.myspoti.spotify.bridge.BridgeHost
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.ByteArrayInputStream

/**
 * [BridgeHost] on an Android WebView that loads the official Web Player.
 *
 * - The WebView is built on the application context, so playback outlives activities.
 * - Desktop user agent: on a phone UA the Web Player only offers to open the app.
 * - Protected media (Widevine) is allowed; what [AdBlock] refuses is refused (its ad and tracker
 *   hosts, only while the music plays on a Spotify Connect device sent from the app).
 * - [loginRequired] turns true on Spotify's login pages: the UI then shows [view] so the
 *   user signs in on Spotify's own page.
 */
class WebPlayerHost(private val context: Context) : BridgeHost {
    private val main = Handler(Looper.getMainLooper())

    // DROP_OLDEST: tryEmit under a main-thread stall must not drop the newest
    // state/result (the default SUSPEND overflow drops exactly the new value).
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 256, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    override val messages: SharedFlow<String> = _messages

    private val _url = MutableStateFlow("")
    /** The page's current URL. */
    val url: StateFlow<String> = _url

    private val _online = MutableStateFlow(true)
    /**
     * The phone's default network can reach the internet (airplane mode, no signal: false). Kept by
     * [watchNetwork]; true when connectivity cannot be watched, so nothing is held for nothing.
     */
    val online: StateFlow<Boolean> = _online

    /*
     * Spotify limiting this client: measured on the test phone after an evening of test runs,
     * the page asked for an audio licence ~4 times a second, each answered 429, and every repair
     * (reload, replay) asked again. A storm of them ends playback here for a while (growing on
     * repeats) instead of feeding it; [licenseLimitedUntil] tells the app and the player.
     */
    @Volatile private var heldLicenses = 0
    @Volatile private var licenseAnswersLogged = 0
    private val license429 = ArrayDeque<Long>()
    private var limitStreak = 0
    private var lastLimitAt = 0L
    private val _licenseLimitedUntil = MutableStateFlow(0L)
    /** Elapsed-realtime end of the current hold, 0 or past when none. */
    val licenseLimitedUntil: StateFlow<Long> = _licenseLimitedUntil
    fun licenseLimited(): Boolean = android.os.SystemClock.elapsedRealtime() < _licenseLimitedUntil.value

    /**
     * When Spotify last refused this page an audio licence (403 and the like, not a 429 limit). The
     * page then skips the song by itself, and on to the next one, a second or so each: those moves are
     * not the user's (see the listen sync, app.myspoti.spotify.sync.SpotifyListenSync).
     */
    @Volatile private var licenceRefusedAt = 0L
    fun licenceRefusedWithin(ms: Long): Boolean =
        licenceRefusedAt != 0L && android.os.SystemClock.elapsedRealtime() - licenceRefusedAt < ms

    private fun onLicenseLimited() = synchronized(license429) {
        val now = android.os.SystemClock.elapsedRealtime()
        license429.addLast(now)
        while (license429.isNotEmpty() && now - license429.first() > LIMIT_WINDOW_MS) license429.removeFirst()
        if (license429.size < LIMIT_COUNT || licenseLimited()) return@synchronized
        if (now - lastLimitAt > LIMIT_FORGET_MS) limitStreak = 0
        lastLimitAt = now
        val hold = (LIMIT_HOLD_MS shl limitStreak.coerceAtMost(4)).coerceAtMost(LIMIT_HOLD_MAX_MS)
        limitStreak++
        license429.clear()
        Logbook.log("Spotify is limiting audio licences (429 x$LIMIT_COUNT in ${LIMIT_WINDOW_MS / 1000} s): playback held ${hold / 1000} s")
        heldLicenses = 0
        _licenseLimitedUntil.value = now + hold
    }

    private val _loginRequired = MutableStateFlow(false)
    val loginRequired: StateFlow<Boolean> = _loginRequired

    private val _loginLoad = MutableStateFlow(LoginLoad.NONE)
    /** How the sign-in page is opening: the UI covers it while it loads and shows an error if it fails. */
    val loginLoad: StateFlow<LoginLoad> = _loginLoad

    /** Fires after each Web Player page load; the API injects the bridge then. */
    var onPageLoaded: (() -> Unit)? = null

    /** Fires when a Web Player page load starts: the old page and its bridge are gone. */
    var onPageStarting: (() -> Unit)? = null

    /** Debug builds: extra logging (a proxy that fails, a device name rewritten…) — and CDP. */
    private val debuggable = context.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE != 0

    /**
     * This install's browser identity, drawn once (see [Fingerprint]) and handed to the API as
     * well: the page and the app's own calls must present the *same* browser, or the difference
     * between them is itself the tell.
     */
    internal val fingerprint = Fingerprint.of(context)
    val userAgent: String get() = fingerprint.userAgent

    init {
        // Debug builds only: lets desktop tools (chrome://inspect, CDP) look at the page.
        if (debuggable) WebView.setWebContentsDebuggingEnabled(true)
        watchNetwork()
    }

    /**
     * The phone moves to another network (Wi-Fi to mobile data, or back): the relay's pooled
     * connections still go through the old one, and a command sent on one of them only waited for
     * its timeout. The idle ones are dropped, so the next command opens a connection on the new
     * network; one already waiting fails within the relay's read timeout. The callback runs on the
     * system's network thread, which is where the sockets may be closed.
     */
    private fun watchNetwork() {
        val connectivity = context.getSystemService(android.net.ConnectivityManager::class.java) ?: return
        runCatching {
            // No default network at start (airplane mode) calls nothing: the state is read once here.
            _online.value = hasInternet(connectivity.getNetworkCapabilities(connectivity.activeNetwork))
            connectivity.registerDefaultNetworkCallback(object : android.net.ConnectivityManager.NetworkCallback() {
                private var current: android.net.Network? = null

                override fun onAvailable(network: android.net.Network) {
                    val was = current
                    current = network
                    setOnline(true)
                    // The first call names the network the app started on: nothing to drop.
                    if (was == null || was == network) return
                    Logbook.log("network changed: the relay's and the API's idle connections dropped")
                    ControlRelay.resetConnections()
                    MyspotiRuntime.resetApiConnections()
                }

                override fun onCapabilitiesChanged(network: android.net.Network, caps: android.net.NetworkCapabilities) {
                    if (network == current) setOnline(hasInternet(caps))
                }

                // Called for the default network only when no other one takes its place.
                override fun onLost(network: android.net.Network) {
                    if (network != current) return
                    current = null
                    setOnline(false)
                }
            })
        }.onFailure { _online.value = true; Logbook.log("network changes not watched: ${it.message}") }
    }

    /*
     * INTERNET, not VALIDATED: a network the system has not validated (some carriers, a portal
     * that answers late) still plays, and taking it for offline held every repair on it.
     */
    private fun hasInternet(caps: android.net.NetworkCapabilities?): Boolean =
        caps?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) == true

    /**
     * Offline, the player's repairs wait (see MyspotiRuntime): a seek, a reload or a skip can do
     * nothing without a network but throw the page away. The network back, a player page that
     * failed to load meanwhile is loaded again at once rather than at its next retry.
     */
    private fun setOnline(now: Boolean) {
        if (_online.value == now) return
        _online.value = now
        Logbook.log(if (now) "network back: repairs resume" else "network lost: repairs held until it is back")
        if (now) main.post {
            if (!mainFrameFailed || !loadAsked || _loginRequired.value) return@post
            pageFailures = 0
            main.removeCallbacks(retryPlayerPage)
            retryPlayerPage.run()
        }
    }

    private lateinit var relay: ControlRelay

    /** The guarded fallback channel of the bridge's messages, when the WebView has no web message listener. */
    private var hostChannel: PlayerChannel? = null

    /** Hands the page that starts its secret for the fallback channels; the relay's script comes after. */
    private fun armChannels(view: WebView, renew: Boolean) {
        for (channel in listOfNotNull(hostChannel, relay.channel)) {
            if (renew) channel.newPage()
            view.evaluateJavascript(channel.shim(), null)
        }
    }

    /** Fetches the audio files itself: the last request the WebView would stamp with its package. */
    private val media = MediaProxy(MediaProxy.client()) { relay.identityPair() }

    /**
     * WebView profiles (androidx.webkit MULTI_PROFILE): each account keeps its own cookies and Web
     * storage, so several stay signed in at once. Without them (an older WebView) the page holds one
     * account at a time, in the default profile, as before.
     */
    val multiProfile: Boolean = runCatching {
        androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)
    }.getOrDefault(false)

    /** The accounts kept on this phone and the active one ([AccountList]). */
    val accounts = AccountStore(java.io.File(context.filesDir, "spotify/accounts.json"))

    /** The profile the page is built with: the active account's, chosen before the WebView loads anything. */
    @Volatile var profile: String = if (multiProfile) accounts.list.value.active else AccountList.DEFAULT_PROFILE
        private set

    init {
        if (!multiProfile && accounts.list.value.active != AccountList.DEFAULT_PROFILE) {
            // The WebView lost its profiles (downgraded): the default one is all there is.
            accounts.update { it.copy(active = AccountList.DEFAULT_PROFILE) }
        }
        purgeRemovedProfiles()
    }

    @SuppressLint("SetJavaScriptEnabled")
    var view: WebView = createView()

    /**
     * Builds the page view. Called once at startup, and again after a renderer crash: a WebView
     * whose renderer died can never be reused, and Android kills the process if one is used after
     * [onRenderProcessGone] returns false (see [rebuild]).
     */
    @SuppressLint("SetJavaScriptEnabled")
    private fun createView(): WebView = AwakeWebView(android.content.MutableContextWrapper(context.applicationContext)).apply {
        // The account's profile, before anything else is done with the view (androidx.webkit's rule).
        useProfile(this)
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            userAgentString = fingerprint.userAgent
            cacheMode = WebSettings.LOAD_DEFAULT
            loadWithOverviewMode = true
            useWideViewPort = true
        }
        // The WebView stamps every request the page makes with "X-Requested-With: <our package>".
        // No browser does that, and it is measured on the wire ([tools/cdp.py] --trace --headers):
        // it rode on the audio files themselves and on Spotify's telemetry, so a single rule on
        // Spotify's side would flag every Myspoti install. The androidx API was made to allow that
        // header for a few origins; an empty allowlist is what suppresses it everywhere.
        if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
            androidx.webkit.WebSettingsCompat.setRequestedWithHeaderOriginAllowList(settings, emptySet())
            Logbook.log("x-requested-with: off for every origin")
        } else {
            Logbook.log("x-requested-with: cannot be turned off on this WebView")
        }
        // Client hints must agree with the desktop user agent: by default the WebView announces
        // "Android WebView" / mobile in Sec-CH-UA headers and navigator.userAgentData.
        if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.USER_AGENT_METADATA)) {
            val brands = fingerprint.brands.map {
                androidx.webkit.UserAgentMetadata.BrandVersion.Builder().setBrand(it.name).setMajorVersion(it.major).setFullVersion(it.fullVersion).build()
            }
            androidx.webkit.WebSettingsCompat.setUserAgentMetadata(settings, androidx.webkit.UserAgentMetadata.Builder()
                .setBrandVersionList(brands)
                .setFullVersion(fingerprint.fullVersion)
                .setPlatform("Linux")
                .setPlatformVersion(fingerprint.kernel)
                .setArchitecture("x86")
                .setBitness(64)
                .setMobile(false)
                .setModel("")
                .setWow64(false)
                .build())
        }
        // The page plays the audio: its renderer keeps its priority when the screen is off.
        setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
        // Playback control requests leave from the app, without the WebView's X-Requested-With.
        relay = ControlRelay(this, fingerprint).also {
            it.onDeviceRegistered = { drmAsked = true; main.removeCallbacks(drmWatch) }
            // An idle page starting to play by itself (a transfer from another device): awake at
            // once, before its state comes and makes it of use.
            it.onPlaybackReport = { wake(REPORT_AWAKE_MS) }
            it.install()
        }
        val webView = this
        cookies().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }
        hostChannel = exposeToPlayer("MyspotiHost") { json -> _messages.tryEmit(json) }
        webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(message: android.webkit.ConsoleMessage): Boolean {
                if (message.messageLevel() == android.webkit.ConsoleMessage.MessageLevel.ERROR ||
                    message.messageLevel() == android.webkit.ConsoleMessage.MessageLevel.WARNING) {
                    // The page's steady console noise (font preloads, storage access refused on
                    // every load) never helped a report: left out.
                    if (CONSOLE_NOISE.none { it.containsMatchIn(message.message()) })
                        Logbook.log("console ${message.messageLevel()}: ${message.message().take(300)}")
                }
                return true
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                Logbook.log("permission request: ${request.resources.joinToString()}")
                if (PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID in request.resources) { drmAsked = true; main.removeCallbacks(drmWatch) }
                val allowed = request.resources.filter { it == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID }
                if (allowed.isNotEmpty()) request.grant(allowed.toTypedArray()) else request.deny()
            }
        }
        webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url.toString()
                if (AdBlock.isBlocked(url)) {
                    Logbook.log("blocked request ${Logbook.noQuery(url).take(120)}")
                    // Refused like a blocked request.
                    return WebResourceResponse("text/plain", "utf-8", 403, "Blocked", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                }
                // Spotify is limiting audio licences (429) and the app holds playback: the page still
                // skips on by itself through every song it gets no licence for (measured in the 25/10
                // logs: 20 to 25 more licence requests in the 4 s after the hold began, ~4 a second,
                // every one answered 429). Those are not sent: the page gets the same 429 from here
                // and Spotify sees no more of them while the hold lasts. With the headers Spotify's own
                // answer has for the page (log seen, 2.0.2-beta.5: without them the page read a CORS
                // failure, status 0, not a 429) and the hold's time left.
                if (request.method == "POST" && licenseLimited() && url.contains(LICENSE_PATH)) {
                    if (heldLicenses++ == 0) Logbook.log("audio licence requests answered here while Spotify is limiting")
                    app.myspoti.spotify.report.Refusal402.licenceHeld()
                    val left = ((_licenseLimitedUntil.value - android.os.SystemClock.elapsedRealtime()) / 1000).coerceAtLeast(1)
                    val headers = mapOf(
                        "Access-Control-Allow-Origin" to PLAYER_URL.trimEnd('/'),
                        "Access-Control-Allow-Credentials" to "true",
                        "Access-Control-Expose-Headers" to "Retry-After",
                        "Retry-After" to "$left",
                    )
                    return WebResourceResponse("application/octet-stream", "utf-8", 429, "Too Many Requests", headers, ByteArrayInputStream(ByteArray(0)))
                }
                // The sign-in flow lives on accounts.spotify.com: logging its steps is what turns
                // "the login is stuck" into the exact request that failed (with the status from
                // onReceivedHttpError below). Reported as B37 and unprovable without this trail.
                if (url.startsWith("https://accounts.spotify.com/")) {
                    loginSteps++
                    Logbook.log("login step #$loginSteps ${request.method} ${url.substringAfter("accounts.spotify.com").substringBefore('?').take(90)}")
                }
                // The music itself: fetched here, so the WebView's own package-name header never
                // travels with it (see MediaProxy).
                if (media.handles(url)) {
                    val proxied = media.fetch(request)
                    if (proxied != null) {
                        if (debuggable) Logbook.log("audio proxied ${url.substringAfterLast('/').take(12)}…")
                        return proxied
                    }
                    Logbook.log("audio proxy failed, the WebView fetches it: ${Logbook.noQuery(url).take(110)}")
                }
                return null
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                Logbook.log("page start ${Logbook.noQuery(url).take(120)}")
                mainFrameFailed = false
                // A "finished" comes just before the player's document starts: its wait must not run out on a
                // page still loading (a page thrown away at 10 s, and a cold start of 30 s, on the test phone).
                main.removeCallbacks(drmWatch)
                // A load that never ends (measured: a reload's document request answered nothing
                // for 9 minutes, the page stayed "loading", empty, without the bridge).
                main.removeCallbacks(loadTimeout)
                if (android.net.Uri.parse(url).host == PLAYER_HOST) main.postDelayed(loadTimeout, PAGE_LOAD_TIMEOUT_MS)
                pageStarts++
                // The sign-in page was asked for and Spotify sent us elsewhere (the sign-in is done, or the
                // session was still good: the player): there is no sign-in page left to wait for. Before the
                // address is published, so whoever hides the page for the player does it after this.
                if (!isLoginPage(url) && _loginLoad.value != LoginLoad.NONE && _loginLoad.value != LoginLoad.FAILED) setLoginLoad(LoginLoad.NONE)
                _url.value = url
                _loginRequired.value = isLoginPage(url)
                if (url.startsWith(PLAYER_URL)) { drmAsked = false; licenseAnswersLogged = 0; onPageStarting?.invoke(); armChannels(view, renew = true); relay.injectNow() }
                if (PLAYER_ROOT.matches(url) && url != roots.getString(ROOT_KEY, null)) roots.edit().putString(ROOT_KEY, url).apply()
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
                if (request.url.host?.contains("spotify") == true)
                    Logbook.log("load error ${error.errorCode} ${error.description} ${Logbook.noQuery(request.url.toString()).take(120)}")
                // ERR_ABORTED: a load this app stopped itself (a timeout, a newer load) — not a failure.
                if (request.isForMainFrame && request.url.host == PLAYER_HOST && "ERR_ABORTED" !in error.description.toString())
                    playerPageFailed("load error ${error.errorCode}")
                // The sign-in page itself: the WebView's own error page is not something to leave a user on.
                if (request.isForMainFrame && _loginLoad.value != LoginLoad.NONE && LoginLoad.isSpotifyAccounts(request.url.toString()) &&
                    "ERR_ABORTED" !in error.description.toString())
                    loginFailed("load error ${error.errorCode}")
            }

            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, response: WebResourceResponse) {
                // Licence answers are counted in the 402 summary and their first ones logged below
                // with their headers; the same 429 three times per song was the bulk of some reports.
                if (request.url.host?.contains("spotify") == true && request.url.path?.contains("widevine-license") != true)
                    Logbook.logEvery("http ${response.statusCode} ${request.url.host}${request.url.path}", 60_000,
                        "http ${response.statusCode} ${request.method} ${request.url.toString().substringBefore('?').take(120)}")
                // The page's own requests answered 401: its token went stale (see PageAuth). A licence or
                // its address (melody license_url) so answered leaves the next song silent: at once.
                if (response.statusCode == 401 && request.url.host?.endsWith("spotify.com") == true && !isLoginPage(_url.value))
                    app.myspoti.spotify.bridge.PageAuth.unauthorized("http ${request.method} ${request.url.path?.take(80)}",
                        licence = request.url.path?.let { it.contains("widevine-license") || it.endsWith("/license_url") } == true)
                if (request.isForMainFrame && request.url.host == PLAYER_HOST && (response.statusCode >= 500 || response.statusCode == 429))
                    playerPageFailed("http ${response.statusCode}")
                if (request.isForMainFrame && _loginLoad.value != LoginLoad.NONE && LoginLoad.isSpotifyAccounts(request.url.toString()) && response.statusCode >= 500)
                    loginFailed("http ${response.statusCode}")
                if (request.url.path?.contains("widevine-license") == true) {
                    if (response.statusCode == 429) onLicenseLimited()
                    else if (response.statusCode in 400..499) licenceRefusedAt = android.os.SystemClock.elapsedRealtime()
                    response.responseHeaders.entries.firstOrNull { it.key.equals("retry-after", true) }
                        ?.let { app.myspoti.spotify.report.Refusal402.licenceRetryAfter(it.value) }
                    // A refused licence (403 seen on a new sign-in, 429 on others) says why in its
                    // headers at best; nothing else of the answer reaches the app. A few per page.
                    if (response.statusCode >= 400 && licenseAnswersLogged++ < LICENSE_ANSWERS_LOGGED) {
                        val h = response.responseHeaders.entries
                            .filter { (k, _) -> k.lowercase() in LICENSE_HEADERS }
                            .joinToString(", ") { (k, v) -> "${k.lowercase()}=${v.take(60)}" }
                        Logbook.log("licence answer ${response.statusCode}: $h")
                    }
                }
            }

            override fun onPageFinished(view: WebView, url: String) {
                Logbook.log("page finished ${Logbook.noQuery(url).take(120)}")
                main.removeCallbacks(loadTimeout)
                if (url.startsWith(PLAYER_URL) && !mainFrameFailed) { pageFailures = 0; main.removeCallbacks(retryPlayerPage) }
                _url.value = url
                _loginRequired.value = isLoginPage(url)
                // Finished is not painted: Spotify's sign-in is a script-built page. Looked at until it has content.
                if (_loginLoad.value == LoginLoad.LOADING && isLoginPage(url)) {
                    loginProbes = 0
                    main.removeCallbacks(loginProbe)
                    main.postDelayed(loginProbe, LoginLoad.FIRST_PROBE_MS)
                }
                if (url.startsWith(PLAYER_URL)) {
                    // Again, same secret: the page start's call may have run before the new document existed.
                    armChannels(view, renew = false)
                    onPageLoaded?.invoke()
                    if (!drmAsked) { main.removeCallbacks(drmWatch); main.postDelayed(drmWatch, DRM_WATCH_MS) }
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val host = request.url.host.orEmpty()
                // Stay on Spotify's own pages (player, login, consent); open nothing else.
                // Exact or subdomain match: "evilspotify.com" must not count as Spotify.
                val allowed = listOf("spotify.com", "spotify.net", "scdn.co", "google.com", "facebook.com", "apple.com")
                    .any { host == it || host.endsWith(".$it") }
                // And only over https: a plain http link to those hosts, or any other scheme, stays out.
                // The page's own loads (loadUrl, about:blank) do not come through here.
                val secure = request.url.scheme == "https"
                // A sign-in step that goes nowhere looks like a page that does nothing: say which host was refused.
                if (!allowed || !secure) Logbook.log("navigation refused: ${host.ifEmpty { request.url.scheme.orEmpty() }}${if (allowed && !secure) " (${request.url.scheme}, not https)" else ""}")
                return !(allowed && secure)
            }

            /**
             * The renderer died (the reported "the app crashed", "playback stops until the player
             * is restarted"). A WebView whose renderer is gone can never be reused, and Android
             * kills the whole process if one is still used after this returns false: the page is
             * rebuilt on a new WebView, and true says "handled, do not kill the app".
             */
            override fun onRenderProcessGone(gone: WebView, detail: RenderProcessGoneDetail): Boolean {
                // Killed (memory pressure) or crashed: both end here. A late callback from a view
                // that was already replaced must not tear down the healthy new one.
                if (gone !== this@WebPlayerHost.view) return true
                Logbook.log("renderer gone (crashed=${detail.didCrash()}, priority=${detail.rendererPriorityAtExit()}): rebuilding the page")
                // The page is gone with it: the calls it had fail now, not each after its timeout.
                onPageStarting?.invoke()
                rebuild()
                return true
            }
        }
    }

    /** The container the page is attached to, so a rebuilt page goes back to the same place. */
    private var container: ViewGroup? = null

    /** Whether the page was shown full screen at the last [attach] (login). */
    private var lastVisible = false

    /**
     * Replaces the page after its renderer died: the dead WebView is destroyed rather than reused,
     * the new one takes its place in the same container, and the page loads again. Without this
     * the app kept a dead page — a blank screen with the sound gone — until it was restarted.
     */
    private fun rebuild(then: (() -> Unit)? = null): Boolean = main.post {
        main.removeCallbacks(drmWatch)
        val wasLoaded = loadAsked
        // Mid sign-in: the page comes back to the sign-in, not to an anonymous player in front of the user.
        val wasLogin = _loginRequired.value || _loginLoad.value != LoginLoad.NONE
        val box = container
        box?.let { runCatching { it.removeView(view) } }
        (view as? AwakeWebView)?.releaseFromWindow()
        runCatching { view.stopLoading() }
        runCatching { view.destroy() }
        view = createView()
        applyAwake()
        pageStarts = 0
        _url.value = ""
        // attach() loads the page itself when a load is pending; the pending load is asked again
        // just after, once, so a rebuilt page is loaded exactly once.
        loadAsked = false
        box?.let { attach(it, lastVisible) }
        // Another account's page ([switchProfile], [addProfile]): what it opens on is the caller's.
        if (then != null) { then(); return@post }
        // The new view's first navigation can be lost while the browser side still settles after
        // the kill (seen: no page start for 4 s): the watchdog looks again after 1.5 s, not 4 s.
        if (wasLogin) { loadAsked = wasLoaded; beginLoginLoad(); view.loadUrl(LOGIN_URL) }
        else if (wasLoaded) load(firstWatchMs = REBUILD_WATCH_MS) else view.loadUrl("about:blank")
    }

    /** Spotify's sign-in pages and the "Continue with Google / Facebook / Apple" ones (see [LoginLoad.isLoginUrl]). */
    private fun isLoginPage(url: String?) = LoginLoad.isLoginUrl(url)

    fun load() = load(firstWatchMs = LOAD_WATCH_MS)

    private fun load(firstWatchMs: Long) = main.post {
        pageStarts = 0
        loadAsked = true
        view.loadUrl(playerRoot())
        watchLoad(playerRoot(), attempt = 1, firstWatchMs)
    }

    /** Page starts since the last [load]; the load watchdog looks at it. */
    private var pageStarts = 0

    /** Sign-in requests seen (accounts.spotify.com): a trail for a login that goes nowhere. */
    private var loginSteps = 0
    /** [load] was called and no [unload] since (data saver keeps the page off). */
    private var loadAsked = false

    /**
     * An exec-spawned process (GrapheneOS "secure app spawning") can lose the first
     * navigation of a WebView made in Application.onCreate: no page start, ever. When
     * nothing started after a while, the page is asked for again (a few times, further apart).
     */
    private fun watchLoad(url: String, attempt: Int, firstWatchMs: Long = LOAD_WATCH_MS) {
        main.postDelayed({
            if (pageStarts > 0 || !loadAsked || attempt > LOAD_RETRIES) return@postDelayed
            Logbook.log("page never started: loading again (attempt $attempt)")
            if (attempt > 1) view.stopLoading()
            view.loadUrl(url)
            watchLoad(url, attempt + 1)
        }, if (attempt == 1) firstWatchMs else LOAD_WATCH_MS * attempt)
    }

    private val roots by lazy { context.getSharedPreferences("web_player", Context.MODE_PRIVATE) }

    /**
     * When a signed-in session was first seen in this WebView since the last sign-out: 0 never,
     * -1 one already signed in when this was first noted (its age unknown). For the report's
     * summary only (audio licences refused on sign-ins less than a day old, 30/10): a date, no account.
     */
    val signedInSince: Long get() = roots.getLong(SIGNED_IN_KEY, 0L)

    /** A signed-in session is there; [fresh]: it came after a login page or an anonymous one in this run. */
    fun noteSignedIn(fresh: Boolean) {
        if (signedInSince != 0L) return
        roots.edit().putLong(SIGNED_IN_KEY, if (fresh) System.currentTimeMillis() else -1L).apply()
    }

    /**
     * Where Spotify sends "/" for this account's language (`…/intl-fr/`), loaded directly: the
     * redirect cost a whole navigation, about 0.5 s, on every start and reload (measured on the
     * test phone). Learnt from the last load; a language where "/" is final keeps [PLAYER_URL].
     */
    private fun playerRoot(): String = roots.getString(ROOT_KEY, null)?.takeIf { PLAYER_ROOT.matches(it) } ?: PLAYER_URL

    /** The player's own URL, not the page's current one: the bridge parks the page on an empty route. */
    fun reload() = main.post {
        // A page whose player never started is not helped by loading it again in the same renderer.
        if (pageStarts > 0 && !drmAsked && _url.value.startsWith(PLAYER_URL) && newViewAllowed()) {
            Logbook.log("reload: the player never started on this page (no DRM request): new WebView instead")
            rebuild()
        } else view.loadUrl(playerRoot())
    }

    /**
     * The page's player started since the page last started: it asked for DRM (Widevine), as it
     * does on every load, or its playback device was registered. A page that never asks never registers its device, and every command
     * then fails with "No such device" (seen on a Xiaomi just after signing in: six minutes and
     * five reloads, until the renderer was replaced, after which it asked at once).
     */
    @Volatile private var drmAsked = false

    /** Times the page was put on a new WebView because its player never started (at most 2 in 10 min). */
    private val drmRebuilds = ArrayDeque<Long>()

    private fun newViewAllowed(): Boolean {
        val now = android.os.SystemClock.elapsedRealtime()
        while (drmRebuilds.isNotEmpty() && now - drmRebuilds.first() > DRM_REBUILD_WINDOW_MS) drmRebuilds.removeFirst()
        if (drmRebuilds.size >= DRM_REBUILDS_MAX) return false
        drmRebuilds.addLast(now)
        return true
    }

    private val drmWatch: Runnable = Runnable {
        if (drmAsked || !loadAsked || !_url.value.startsWith(PLAYER_URL) || isLoginPage(_url.value)) return@Runnable
        if (!newViewAllowed()) { Logbook.log("player never started on this page (no DRM request); new WebViews used up for now"); return@Runnable }
        Logbook.log("player never started on this page (no DRM request ${DRM_WATCH_MS / 1000} s after load): new WebView")
        rebuild()
    }

    /**
     * Hides the page without hiding it from Chromium (it keeps running as on screen): after the
     * sign-in, while the session is being confirmed, the app's own waiting screen shows instead of
     * Spotify's desktop player (reported: it flashed before the first screen). [attach] and
     * [openLogin] show it again.
     */
    fun veil(on: Boolean) = main.post { view.alpha = if (on) 0f else 1f }

    /*
     * A player page that did not load (Spotify answering 504 to a reload, the network down at that
     * moment) used to stay what it was: an error page, "not ready", every command refused, until
     * the app was restarted (seen on the test phone after an ad recovery's reload). It is loaded
     * again, sooner first, then once a minute, until a page loads.
     */
    private var mainFrameFailed = false
    private var pageFailures = 0
    private val retryPlayerPage = Runnable {
        if (!loadAsked || _loginRequired.value) return@Runnable
        // Offline, the load could only fail again: [setOnline] loads it when the network is back.
        if (!_online.value) { Logbook.log("player page: offline, loaded again when the network is back"); return@Runnable }
        Logbook.log("player page: load again (attempt ${pageFailures + 1})")
        view.stopLoading()
        view.loadUrl(playerRoot())
    }
    private val loadTimeout = Runnable {
        if (!loadAsked || _loginRequired.value) return@Runnable
        view.stopLoading()
        playerPageFailed("still loading after ${PAGE_LOAD_TIMEOUT_MS / 1000} s")
    }

    private fun playerPageFailed(what: String) {
        mainFrameFailed = true
        val wait = RETRY_PAGE_MS[pageFailures.coerceAtMost(RETRY_PAGE_MS.lastIndex)]
        pageFailures++
        Logbook.log("player page failed to load ($what): again in ${wait / 1000} s")
        main.removeCallbacks(retryPlayerPage)
        main.postDelayed(retryPlayerPage, wait)
    }

    fun openLogin() = main.post {
        // A player retry or load timeout still pending would replace the sign-in page just asked for.
        main.removeCallbacks(retryPlayerPage)
        main.removeCallbacks(loadTimeout)
        beginLoginLoad()
        view.loadUrl(LOGIN_URL)
    }

    /** Signs out of Spotify in this WebView, then shows the login page. */
    fun logout() = main.post {
        roots.edit().remove(SIGNED_IN_KEY).apply()
        // The profile stays, with no account in it: the next sign-in on it is read as whoever it is.
        accounts.update { it.signedOut(profile) }
        beginLoginLoad()
        cleanSlate { view.loadUrl(LOGIN_URL) }
    }

    /**
     * "Try again" after the sign-in page failed: from nothing. A failed attempt may have left half
     * a sign-in behind (the cookies and storage of a flow that never finished), and Spotify's page
     * answers "Oops! Something went wrong" to a flow it cannot match with its own state.
     */
    fun retryLogin() = main.post { beginLoginLoad(); cleanSlate { view.loadUrl(LOGIN_URL) } }

    /**
     * Before a report sent from the sign-in: what the page shows right now (its path, title, the
     * error messages on it, which kind of step), into the log. The failed sign-ins reported
     * ("Oops! Something went wrong", an e-mail not recognised, a page that loads for ever) came
     * with no trail of the page itself. Typed values are never read; e-mails are masked by the log.
     * [done] runs on the main thread, after the answer or 1.5 s.
     */
    fun noteLoginPage(done: () -> Unit) = main.post {
        var finished = false
        val finish = { if (!finished) { finished = true; done() } }
        val url = _url.value
        Logbook.log("report asked from the sign-in: ${Logbook.noQuery(url).take(120)} load=${_loginLoad.value} steps=$loginSteps")
        if (!isLoginPage(url) && !LoginLoad.isSpotifyAccounts(url)) { finish(); return@post }
        main.postDelayed({ finish() }, 1_500)
        view.evaluateJavascript(LOGIN_PAGE_STATE_JS) { answer ->
            Logbook.log("sign-in page now: ${answer?.take(600)}")
            finish()
        }
    }

    private fun cleanSlate(then: () -> Unit) {
        cookies().removeAllCookies {
            main.post {
                // Web storage too: localStorage/IndexedDB hold the player's session
                // state, and clearCache(true) also drops the disk cache (false kept it).
                webStorage().deleteAllData()
                view.clearCache(true)
                then()
            }
        }
    }

    /**
     * Writes the session cookies to disk now. The WebView keeps them in memory and saves them a
     * while later: an app swiped away right after signing in (the exit log shows "SwipeUpClean" and
     * "OneKeyClean" on Xiaomi) lost the sign-in and asked for it again at the next start.
     */
    fun flushCookies() = cookies().flush()

    /** The active profile's cookies (the default ones without profiles). Main thread. */
    fun cookies(): CookieManager =
        if (multiProfile) androidx.webkit.ProfileStore.getInstance().getOrCreateProfile(profile).cookieManager
        else CookieManager.getInstance()

    private fun webStorage(): android.webkit.WebStorage =
        if (multiProfile) androidx.webkit.ProfileStore.getInstance().getOrCreateProfile(profile).webStorage
        else android.webkit.WebStorage.getInstance()

    /**
     * Puts [webView] on the active account's profile, so it shares the page's sign-in (the account
     * pages' browser). Call it on a new view, before anything else is done with it. Main thread.
     */
    fun useProfile(webView: WebView) {
        if (!multiProfile) return
        androidx.webkit.ProfileStore.getInstance().getOrCreateProfile(profile)
        androidx.webkit.WebViewCompat.setProfile(webView, profile)
    }

    /**
     * The page moves to the account kept in [profileName]: a new WebView on that profile (its own
     * cookies and storage), built as after a dead renderer ([rebuild]), opening the player. Whoever
     * follows the account (the API's token and username, the plan, the app's caches) forgets it on
     * the caller's side. Nothing without profiles (the caller signs out instead).
     */
    fun switchProfile(profileName: String) {
        if (!multiProfile) return
        val list = accounts.update { it.switchTo(profileName, System.currentTimeMillis()) }
        if (list.active != profileName) return
        moveTo(profileName) { load(firstWatchMs = REBUILD_WATCH_MS) }
    }

    /** "Add account": a new, empty profile becomes the active one and opens Spotify's sign-in page. */
    fun addProfile() {
        if (!multiProfile) return
        var name = ""
        accounts.update { list -> list.adding(System.currentTimeMillis()).also { name = it.second }.first }
        moveTo(name) { loadAsked = true; beginLoginLoad(); view.loadUrl(LOGIN_URL) }
    }

    /**
     * [profileName] is no longer kept: its entry goes and its data (cookies, storage, cache) is
     * deleted. The active profile is first left ([switchProfile]); the default profile cannot be
     * deleted and is cleared instead. A profile still held by a WebView is deleted at the next start.
     */
    fun removeProfile(profileName: String) {
        if (profileName == accounts.list.value.active) return
        accounts.update { it.removed(profileName) }
        main.post { purgeRemovedProfiles() }
        // The replaced WebView may take a moment to let its profile go.
        main.postDelayed({ purgeRemovedProfiles() }, PURGE_RETRY_MS)
    }

    private fun moveTo(profileName: String, open: () -> Unit) = main.post {
        Logbook.log("account: page moved to another profile")
        profile = profileName
        // Both said something of the account that leaves: when it signed in, and its language's root.
        roots.edit().remove(SIGNED_IN_KEY).remove(ROOT_KEY).apply()
        main.removeCallbacks(retryPlayerPage)
        main.removeCallbacks(loadTimeout)
        mainFrameFailed = false
        pageFailures = 0
        // A sign-in left open on the old page (back from an added account's) is not this page's:
        // its clocks stop, and nothing reads "sign-in page" until the new page says so itself.
        setLoginLoad(LoginLoad.NONE)
        _loginRequired.value = false
        // The page is gone: the calls it had fail now, not each after its timeout.
        onPageStarting?.invoke()
        rebuild(then = open)
        main.post { purgeRemovedProfiles() }
    }

    /** Deletes the data of the profiles removed ([AccountList.doomed]); one still in use waits for later. Main thread. */
    private fun purgeRemovedProfiles() {
        if (!multiProfile) return
        for (name in accounts.list.value.doomed) {
            if (name == profile) continue
            val done = runCatching {
                val store = androidx.webkit.ProfileStore.getInstance()
                if (name == AccountList.DEFAULT_PROFILE) {
                    store.getProfile(name)?.let { p -> p.cookieManager.removeAllCookies(null); p.webStorage.deleteAllData() }
                } else store.deleteProfile(name)
            }
            if (done.isSuccess) accounts.update { it.deleted(name) }
            else Logbook.log("account: a removed profile is still in use, deleted later (${done.exceptionOrNull()?.javaClass?.simpleName})")
        }
    }

    private var loginProbes = 0
    private var loginReloaded = false

    /** The sign-in page was asked for: kept out of sight, with its clocks running, until it has content. */
    private fun beginLoginLoad() {
        loginProbes = 0
        loginReloaded = false
        main.removeCallbacks(loginProbe)
        main.removeCallbacks(loginTimeout)
        _loginLoad.value = LoginLoad.LOADING
        view.alpha = 0f
        main.postDelayed(loginTimeout, LoginLoad.TIMEOUT_MS)
        Logbook.log("sign-in page: opening")
    }

    private fun setLoginLoad(state: LoginLoad) {
        if (_loginLoad.value == state) return
        _loginLoad.value = state
        if (state != LoginLoad.LOADING) { main.removeCallbacks(loginProbe); main.removeCallbacks(loginTimeout) }
        if (state == LoginLoad.SHOWN || state == LoginLoad.NONE) view.alpha = 1f
        if (state == LoginLoad.NONE) return
        Logbook.log("sign-in page: ${state.name.lowercase()}")
    }

    private fun loginFailed(what: String) {
        if (_loginLoad.value == LoginLoad.FAILED) return
        Logbook.log("sign-in page failed ($what)")
        runCatching { view.stopLoading() }
        view.alpha = 0f
        setLoginLoad(LoginLoad.FAILED)
    }

    private val loginTimeout = Runnable {
        if (_loginLoad.value != LoginLoad.LOADING) return@Runnable
        // A page can show everything and still be "loading" (a stuck script or tracker): content decides.
        view.evaluateJavascript(LoginLoad.PAINT_JS) { answer ->
            if (_loginLoad.value != LoginLoad.LOADING) return@evaluateJavascript
            if (LoginLoad.painted(answer) && isLoginPage(view.url)) setLoginLoad(LoginLoad.SHOWN)
            else loginFailed("no content after ${LoginLoad.TIMEOUT_MS / 1000} s")
        }
    }

    /** Asks the page how much it shows; empty after its load finished means a page that did not run. */
    private val loginProbe: Runnable = Runnable {
        if (_loginLoad.value != LoginLoad.LOADING) return@Runnable
        view.evaluateJavascript(LoginLoad.PAINT_JS) { answer ->
            if (_loginLoad.value != LoginLoad.LOADING) return@evaluateJavascript
            if (LoginLoad.painted(answer)) { setLoginLoad(LoginLoad.SHOWN); return@evaluateJavascript }
            when (LoginLoad.blank(++loginProbes, loginReloaded)) {
                LoginLoad.Blank.WAIT -> main.postDelayed(loginProbe, LoginLoad.PROBE_EVERY_MS)
                LoginLoad.Blank.RELOAD -> {
                    Logbook.log("sign-in page: finished but blank, loading it again")
                    loginReloaded = true
                    loginProbes = 0
                    view.loadUrl(LOGIN_URL)
                }
                LoginLoad.Blank.FAIL -> loginFailed("blank after a second load")
            }
        }
    }

    override suspend fun evaluate(script: String) {
        val done = CompletableDeferred<Unit>()
        main.post {
            runCatching { view.evaluateJavascript(script, null) }
                .onFailure { Logbook.log("script not run in the page: ${it.message}") }
            done.complete(Unit)
        }
        done.await()
    }

    /** The page's own answer: a call that never reached the bridge fails now, not after its timeout. */
    override suspend fun evaluateValue(script: String): String? {
        val done = CompletableDeferred<String?>()
        main.post {
            runCatching { view.evaluateJavascript(script) { value -> done.complete(value) } }
                .onFailure { done.completeExceptionally(app.myspoti.spotify.bridge.BridgeException("page not reachable: ${it.message}")) }
        }
        return done.await()
    }

    /**
     * Keeps the page attached to a window, a tiny non-interactive view in [container] while the
     * player is hidden.
     *
     * Hidden means INVISIBLE, not a 1 px view at 1 % alpha: a drawn WebView is replayed by the
     * app's RenderThread on every frame the app draws (measured with Perfetto on the player
     * screen: `WebViewFunctor::drawVk` 3.7 ms plus a 1.5 ms `postAndWait` on the UI thread, per
     * frame, for a pixel nobody sees), and the page kept animating its own UI underneath. The
     * page then runs as it already does whenever the app is in the background or the screen is
     * off, which is how most listening happens.
     */
    fun attach(container: ViewGroup, visible: Boolean) = main.post {
        this.container = container
        lastVisible = visible
        // A <select> (the birth month on Spotify's sign-up page) opens its list as a dialog, which
        // needs an Activity: shown, the page works on the activity's context; hidden, on the
        // application's again, so no activity is kept by a page that outlives them. Same page, no reload.
        (view.context as? android.content.MutableContextWrapper)?.baseContext =
            if (visible) container.context else context.applicationContext
        // Re-added each time: addView converts the params to the container's own type
        // (assigning plain ViewGroup.LayoutParams to a FrameLayout child crashes on measure).
        (view.parent as? ViewGroup)?.removeView(view)
        val size = if (visible) ViewGroup.LayoutParams.MATCH_PARENT else 1
        container.addView(view, ViewGroup.LayoutParams(size, size))
        keepClearOfSystemBars(visible)
        // Still opening or failed, the sign-in page stays out of sight (the app's own screen covers it).
        view.alpha = if (_loginLoad.value == LoginLoad.LOADING || _loginLoad.value == LoginLoad.FAILED) 0f else 1f
        view.visibility = if (visible) View.VISIBLE else View.INVISIBLE
        view.importantForAccessibility = if (visible) View.IMPORTANT_FOR_ACCESSIBILITY_AUTO else View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        // Typing in the login form needs touch focus, or the keyboard never opens.
        view.isFocusable = visible
        view.isFocusableInTouchMode = visible
        view.descendantFocusability = if (visible) ViewGroup.FOCUS_AFTER_DESCENDANTS else ViewGroup.FOCUS_BLOCK_DESCENDANTS
        if (visible) view.requestFocus()
        view.requestLayout()
        // Shown again after being hidden at 1 px: a page that was not told to redraw can stay white.
        if (visible) view.postInvalidateOnAnimation()
        // Now in a window: a first navigation that never started gets another go. Not over a
        // sign-in page being opened on a new view (another account's, or after a dead renderer).
        if (loadAsked && _url.value.isEmpty() && pageStarts == 0 && _loginLoad.value == LoginLoad.NONE) view.loadUrl(playerRoot())
    }

    /**
     * The app draws edge to edge: the login page shown full screen went under the status bar
     * (reported: Spotify's logo under the clock) and its form under the keyboard. Shown, the page
     * keeps clear of the system bars, the cutout and the keyboard; hidden, it takes no room.
     */
    private fun keepClearOfSystemBars(visible: Boolean) {
        val v = view
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(v) { _, insets ->
            val lp = v.layoutParams as? ViewGroup.MarginLayoutParams
            if (lp != null) {
                val bars = if (lastVisible) insets.getInsets(
                    androidx.core.view.WindowInsetsCompat.Type.systemBars() or
                        androidx.core.view.WindowInsetsCompat.Type.displayCutout() or
                        androidx.core.view.WindowInsetsCompat.Type.ime()
                ) else androidx.core.graphics.Insets.NONE
                if (lp.topMargin != bars.top || lp.bottomMargin != bars.bottom || lp.leftMargin != bars.left || lp.rightMargin != bars.right) {
                    lp.setMargins(bars.left, bars.top, bars.right, bars.bottom)
                    v.layoutParams = lp
                }
            }
            insets
        }
        if (visible) androidx.core.view.ViewCompat.requestApplyInsets(v)
        else (v.layoutParams as? ViewGroup.MarginLayoutParams)?.let { it.setMargins(0, 0, 0, 0); v.layoutParams = it }
    }

    /** Only the Activity that owns the current attachment may release it. */
    fun detach(from: ViewGroup) = main.post {
        if (container !== from) return@post
        container = null
        lastVisible = false
        (view.parent as? ViewGroup)?.removeView(view)
        (view.context as? android.content.MutableContextWrapper)?.baseContext = context.applicationContext
    }

    /**
     * Whether the page is of use now ([MyspotiRuntime] says: it plays, an ad is on, another device
     * plays through it, it is not up yet). Useful, Chromium is told it is visible and runs it at
     * full speed; idle, it sees the view as it really is (hidden), and throttles its timers as a
     * background tab's. A command wakes it for [COMMAND_AWAKE_MS] ([commandComing]) before it is sent.
     *
     * Idle, the page still wakes for [BREATH_MS] every [BREATH_EVERY_MS]: Chromium holds a page
     * hidden five minutes without sound to one timer a minute, and the page's keep-alive with
     * Spotify (its Connect presence: the device listed and controllable from the others, a
     * transfer to it) runs on timers. Kept within the first throttling (one timer a second), it
     * never falls that far behind; the battery gain stays (the page sleeps 98 % of the time).
     */
    fun setUseful(on: Boolean) = main.post {
        useful = on
        applyAwake()
        main.removeCallbacks(breath)
        if (!on) main.postDelayed(breath, BREATH_EVERY_MS)
    }

    override fun commandComing() = wake(COMMAND_AWAKE_MS)

    /** The page awake for [ms] at least, then back to what [useful] says. */
    private fun wake(ms: Long) {
        val until = android.os.SystemClock.uptimeMillis() + ms
        if (until <= awakeUntil) return
        awakeUntil = until
        main.post {
            applyAwake()
            main.removeCallbacks(wakeOver)
            main.postDelayed(wakeOver, (awakeUntil - android.os.SystemClock.uptimeMillis()).coerceAtLeast(0))
        }
    }

    @Volatile private var awakeUntil = 0L
    private var useful = true
    private val wakeOver = Runnable { applyAwake() }
    private val breath: Runnable = Runnable {
        if (useful) return@Runnable
        wake(BREATH_MS)
        main.postDelayed(breath, BREATH_EVERY_MS)
    }

    private fun applyAwake() {
        val awake = useful || android.os.SystemClock.uptimeMillis() < awakeUntil
        (view as? AwakeWebView)?.setAwake(awake)
        // The renderer is important only while the page is of use (it plays, mirrors, is asked):
        // idle, it is bound to the app's own priority, never waived (a killed renderer is a reload).
        runCatching { view.setRendererPriorityPolicy(if (awake) WebView.RENDERER_PRIORITY_IMPORTANT else WebView.RENDERER_PRIORITY_BOUND, false) }
    }

    /** Frees the page (data saver, low memory). [load] brings it back. */
    fun unload() = main.post { loadAsked = false; view.loadUrl("about:blank") }

    companion object {
        /** Logcat tag of the engine: `adb logcat -s Myspoti`. */
        const val LOG = "Myspoti"
        const val PLAYER_URL = "https://open.spotify.com/"
        private val PLAYER_ROOT = Regex("""https://open\.spotify\.com/intl-[a-z]{2,3}(?:-[a-zA-Z]{2,4})?/""")
        private const val ROOT_KEY = "player_root"
        private const val SIGNED_IN_KEY = "signed_in_since"
        private const val PLAYER_HOST = "open.spotify.com"
        private const val PAGE_LOAD_TIMEOUT_MS = 25_000L
        private const val DRM_WATCH_MS = 10_000L
        private const val DRM_REBUILDS_MAX = 2
        private const val DRM_REBUILD_WINDOW_MS = 600_000L
        private const val LICENSE_PATH = "/widevine-license/v1/audio/license"
        private const val LICENSE_ANSWERS_LOGGED = 6
        private val CONSOLE_NOISE = listOf(Regex("^The resource .* was preloaded"), Regex("^requestStorageAccess: Permission denied"))
        private val LICENSE_HEADERS = setOf("retry-after", "content-type", "server", "via", "x-ratelimit-remaining", "x-ratelimit-reset", "cf-ray", "x-envoy-upstream-service-time")
        private const val LIMIT_COUNT = 6
        private const val LIMIT_WINDOW_MS = 10_000L
        private const val LIMIT_HOLD_MS = 60_000L
        private const val LIMIT_HOLD_MAX_MS = 600_000L
        private const val LIMIT_FORGET_MS = 1_800_000L
        /**
         * A page that did not load is loaded again after these waits, the last one repeated (a
         * captive portal, a filtered DNS, a blocked country): it was once a minute for ever.
         */
        private val RETRY_PAGE_MS = longArrayOf(2_000, 5_000, 15_000, 30_000, 60_000, 120_000, 300_000, 600_000)
        /** A command keeps an idle page awake this long (its answer, the page's work after it). */
        private const val COMMAND_AWAKE_MS = 10_000L
        /** A playback report of the page's own keeps it awake this long (its state then says whether it plays). */
        private const val REPORT_AWAKE_MS = 3_000L
        /** An idle page wakes this often (under the five minutes after which Chromium holds a hidden page to a timer a minute)... */
        private const val BREATH_EVERY_MS = 4 * 60_000L
        /** ...for this long: the timers due run, and the hidden page's five minutes start again. */
        private const val BREATH_MS = 3_000L
        private const val LOAD_WATCH_MS = 4_000L
        private const val REBUILD_WATCH_MS = 1_500L
        /** A removed profile still held by the WebView just replaced: deleted again after this. */
        private const val PURGE_RETRY_MS = 10_000L
        private const val LOAD_RETRIES = 4
        const val LOGIN_URL = "https://accounts.spotify.com/login?continue=https%3A%2F%2Fopen.spotify.com%2F"

        /**
         * What the sign-in page shows, for [noteLoginPage]: path, title, first heading, the text of its
         * alerts and error banners, and which fields are there (by type, never their values).
         */
        private const val LOGIN_PAGE_STATE_JS = """(function(){try{
var t=function(e){return (e.innerText||'').replace(/\s+/g,' ').trim().slice(0,160)};
var seen={},msgs=[];
document.querySelectorAll('[role=alert],[aria-live],[data-encore-id*=anner],[class*=rror],[class*=anner],[id*=rror]').forEach(function(e){
var s=t(e); if(s&&!seen[s]&&msgs.length<6){seen[s]=1;msgs.push(s)}});
var f=[]; document.querySelectorAll('input').forEach(function(i){if(i.type!=='hidden')f.push(i.type+(i.autocomplete?'/'+i.autocomplete:''))});
var h=document.querySelector('h1,h2');
return JSON.stringify({path:location.host+location.pathname,title:document.title.slice(0,80),heading:h?t(h):null,
messages:msgs,fields:f.slice(0,8),captcha:!!document.querySelector('iframe[src*=captcha],iframe[src*=challenge],[class*=aptcha]'),
ready:document.readyState});
}catch(e){return 'failed: '+e}})()"""
    }
}

/**
 * The engine's WebView, not hidden as far as Chromium knows while it is awake ([setAwake]: the
 * page plays, or a command is on its way). A page Chromium sees hidden has
 * its timers held to one wake-up a second, then to one a minute once it has been hidden five
 * minutes without sound (measured on the test phone, app in the background: eight 38 ms steps
 * took 7.8 s). Everything the page does on a timer waited on that: the fades (a song resumed
 * after a pause stayed nearly silent for seconds), Spotify's own hand-over at the end of a song,
 * and the work behind a command sent after a long pause.
 *
 * Only Chromium is told: the framework still sees the view's real visibility, so a hidden page
 * is never drawn (see [WebPlayerHost.attach]). Chromium reads the view's visibility through
 * [getVisibility], and the window's through [getWindowVisibility] when the view is set up and
 * [onWindowVisibilityChanged] afterwards (the callback alone left the page hidden).
 */
private class AwakeWebView(context: Context) : WebView(context) {
    /** Told visible to Chromium; off, Chromium sees the view's and the window's real visibility. */
    private var awake = true
    /** The window's visibility as the framework last said it. */
    private var realWindowVisibility = View.VISIBLE

    override fun getVisibility(): Int = if (awake) View.VISIBLE else super.getVisibility()
    override fun getWindowVisibility(): Int = if (awake) View.VISIBLE else super.getWindowVisibility()
    override fun onWindowVisibilityChanged(visibility: Int) {
        realWindowVisibility = visibility
        super.onWindowVisibilityChanged(if (awake) View.VISIBLE else visibility)
    }

    /**
     * Idle (nothing played, no command for a while): Chromium is told the truth, so a page nobody
     * uses is throttled as a hidden tab is (timers once a second, then once a minute). Its view and
     * window visibility are both said again, as Chromium reads them only on these calls.
     */
    fun setAwake(on: Boolean) {
        if (on == awake) return
        awake = on
        val window = if (on) View.VISIBLE else if (isAttachedToWindow) realWindowVisibility else View.GONE
        super.onWindowVisibilityChanged(window)
        onVisibilityChanged(this, getVisibility())
    }

    /**
     * Closing the app (swiped from recents, back) destroys the activity and its window, and the
     * view leaves the window with it. Chromium then marks the page's view and window hidden and
     * tears down its compositor: the music stopped for a moment until the player's repair
     * restarted it (reported on build 2022), while the foreground service was still there. The
     * departure is kept from Chromium, as the visibility above is: the page keeps playing as in
     * a window that is on screen, and Chromium is told for real when the view is attached
     * again (the new window needs a fresh attach) or destroyed.
     */
    private var detachHeld = false

    override fun onDetachedFromWindow() {
        detachHeld = true
    }

    override fun onAttachedToWindow() {
        releaseFromWindow()
        super.onAttachedToWindow()
    }

    /** Tells Chromium about a detach that was held back; no-op when none is pending. */
    fun releaseFromWindow() {
        if (!detachHeld) return
        detachHeld = false
        super.onDetachedFromWindow()
    }
}
